@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@	+---------------------------+---------------+		@
@	| Edaeth old-style icon set | Version 1.7.8 |		@
@	+---------------------------+---------------+		@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@								@
@ How-to setup:							@
@								@
@ -1. Locate the Custom UI folder in your DAOC directory.	@
@ -2. Choose the color of your style icons.			@
@ -3. Empty the contents of the Edaethx old-style icon set that	@
@     you want to use into the custom folder.			@
@ -4. Be sure to back up files before overwriting!		@
@ -5. Enjoy!							@
@								@
@								@
@     Edaeth old-style icon set by Edaethx-Lancelot		@
@								@
@     Please PM me on the VNBoards @ Luelota with anything you	@
@     feel should be changed.					@
@								@
@     Thanks =)							@
@								@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

 _____   _____        ___   _____   _____   __   _        _____   _   _   _   _____  
|  _  \ |  _  \      /   | /  ___| /  _  \ |  \ | |      /  ___/ | | | | | | |_   _| 
| | | | | |_| |     / /| | | |     | | | | |   \| |      | |___  | |_| | | |   | |   
| | | | |  _  /    / / | | | |  _  | | | | | |\   |      \___  \ |  _  | | |   | |   
| |_| | | | \ \   / /  | | | |_| | | |_| | | | \  |       ___| | | | | | | |   | |   
|_____/ |_|  \_\ /_/   |_| \_____/ \_____/ |_|  \_|      /_____/ |_| |_| |_|   |_|   